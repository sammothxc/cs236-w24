#pragma once
#include "Token.h"
#include "DatalogProgram.h"
#include "Expression.h"
#include <queue>

class Parser {
    public:
        Parser();
        ~Parser();

        bool DatalogProgram(queue<Token> Tokens);
        string ToString();
protected:
        void PrintFail(int i = 0);
        bool CheckNext(TokenType type);

        Datalog Parse(queue<Token> Tokens);
        bool ParseCheck(TokenType type);
        Predicate ParseScheme();
        vector<Predicate> ParseSchemeList(vector<Predicate> Schemes);
        void ParseIDList();
        vector<Predicate> ParseFactList(vector<Predicate> Facts);
        Predicate ParseFact();
        void ParseStringList();
        vector<Rule> ParseRuleList(vector<Rule> Rules);
        Rule ParseRules();
        Predicate ParseQuery();
        vector<Predicate> ParseQueryList(vector<Predicate> Queries);

        Predicate ParseHeadPredicate();
        Predicate ParsePredicate();
        vector<Predicate> ParsePredicateList(vector<Predicate>);

        Parameter ParseParameter();
        void ParseParameterList();
        string ParseExpression();
        Token ParseOperator();

        void PushOnList(string token);


//VARIABLES
        vector<Parameter> paramList;
        queue<Token> TokenQueue;
        Token thisToken;
        Token nextToken;
        bool fail = false;
        Datalog Everything;
        set<string> Domain;
};